package aplicatia5;
import javax.swing.*;
import java.awt.event.*;
public class Aplicatia5 extends JFrame{
	JButton buton;
	String infoOnComponent = "";
	JList filmeFavorite, culoriFavorite;
	DefaultListModel defListModel = new DefaultListModel();
	JScrollPane scroller;
	
	public static void main(String[] args){
		
		new Aplicatia5();
	}
	
	public Aplicatia5(){
		this.setSize(400,400);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Cadru5");
		JPanel thePanel = new JPanel();
		// Creaza buton
		buton = new JButton("Raspuns");
		ListenForButton lForButton = new ListenForButton();
		buton.addActionListener(lForButton);
		thePanel.add(buton);
		String[] movies = {"Matrix", "Mr.Bean", "Game of Thrones"};
		// Creaza un List Box
		filmeFavorite = new JList(movies);
		// Defineste inaltimea celulei		
		filmeFavorite.setFixedCellHeight(30);
		// Defineste latimea celulei
		filmeFavorite.setFixedCellWidth(150);
		// Defineste nr de selectii
		// MULTIPLE_INTERVAL_SELECTION: Select orice
		// SINGLE_SELECTION: Select numai unul
		// SINGLE_INTERVAL_SELECTION: Select oricat intr=o anumita ordine
		filmeFavorite.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		String[] colors = {"Negru", "Albastru", "Alb", "Verde", "Portocaliu", "Gri", "Roz"};
		// Incarcarea unui string aray intr-un model lista
		for(String color: colors){
			defListModel.addElement(color);
		}
		// Adauga violet la index 2
		defListModel.add(2, "Violet");
		// creaza un List box cu elemente incarcate in DefaultListModel
		culoriFavorite = new JList(defListModel);
		// arata doar 4 elemente deodata
		culoriFavorite.setVisibleRowCount(4);
		// Creaza un scroll bar panel sa parcurga list box
		scroller = new JScrollPane(culoriFavorite, 
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		// Defineste inaltinea celulei
		culoriFavorite.setFixedCellHeight(30);
		// Defineste latimea celulei
		culoriFavorite.setFixedCellWidth(150);
		thePanel.add(filmeFavorite);
		// adauga scrollbar
		thePanel.add(scroller);
		this.add(thePanel);
		this.setVisible(true);
	}
	
		private class ListenForButton implements ActionListener{
				public void actionPerformed(ActionEvent e){
				if(e.getSource() == buton){
					// intoarce true daca lelementul e in lista
					if(defListModel.contains("Negru")) infoOnComponent += "Exista negru\n";
					// verifica daca lista e goala
					if(!defListModel.isEmpty()) infoOnComponent += "Lista nu e goala\n";
					// returneaza nr de lemente din DefaultListModel
					infoOnComponent += "Elemente in lista = " + defListModel.size() + "\n";
					// returneaza primul element din lista
					infoOnComponent += "Primul element " + defListModel.firstElement() + "\n";
					// returneaza ultimul element din lista 
					infoOnComponent += "Ultimul element " + defListModel.lastElement() + "\n";
					// returneaza ultimul element din index 1
					infoOnComponent += "Element in index 1 " + defListModel.get(1) + "\n";
					// sterge elementul din index 0
					defListModel.remove(0);
					// sterge elementul albastru
					defListModel.removeElement("Albastru");
					// Creaza un tablou cu elementele din lista
					Object[] arrayOfList = defListModel.toArray();
					// parcurge tabloul
					for(Object color: arrayOfList){
						infoOnComponent += color + "\n";
					}
					JOptionPane.showMessageDialog(Aplicatia5.this, infoOnComponent, "Informatie", JOptionPane.INFORMATION_MESSAGE);
					
					infoOnComponent = "";
					
				}
			}
		}
	
}
